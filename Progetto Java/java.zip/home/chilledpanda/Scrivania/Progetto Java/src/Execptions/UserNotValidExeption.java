package Execptions;

public class UserNotValidExeption extends Throwable {
}
