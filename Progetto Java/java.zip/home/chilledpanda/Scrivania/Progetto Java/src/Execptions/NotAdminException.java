package Execptions;

public class NotAdminException extends Throwable {
    public NotAdminException(String sos) {
    }

    public NotAdminException() {

    }
}
