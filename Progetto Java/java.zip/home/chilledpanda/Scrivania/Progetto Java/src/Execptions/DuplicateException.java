package Execptions;

public class DuplicateException extends Throwable {
    public DuplicateException(String s) {
    }
}
