package Execptions;

public class DataNotValidExeption extends Exception {
    public DataNotValidExeption(String error) {
    }
}
