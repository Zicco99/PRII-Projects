package Execptions;

public class WrongPassword extends Exception {
    public WrongPassword() {
        super();
    }

    public WrongPassword(String wrongPassword) {
    }
}
