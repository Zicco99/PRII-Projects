package Execptions;

public class DataNotFoundException extends Throwable {
    public DataNotFoundException(String s) {

    }
}
